package segundoparcial;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;


public class Inventario<T extends Serializable & CSVSerializable & Comparable<T>> implements Serializable{
    private static final long serialVersionUID = 1L;
    private List<T> libros = new ArrayList<>();
    
    //mostrar libros del inventario
    public void listarElementos(List<? extends T> lista){
        System.out.println("Lista de libros:");
        for(T elemento : lista){
            System.out.println(elemento);
        }
    }
    
    public void paraCadaElemento(Consumer<? super T> accion){
        for(T elemento : libros){
            accion.accept(elemento);
        }
    }
    
    //agregar libros al inventario
    public void agregar(T libro){
        if(libro==null){
            throw new IllegalArgumentException("No se pueden almacenar libros nulos al inventario");
        }
        libros.add(libro);
    }
    
    //obtener libros por indice
    private void validarIndice(int indice){
        if(indice < 0 || indice >= libros.size()){
            throw new IndexOutOfBoundsException("Indice invalido");
        }
    }
    public T obtener(int indice){
        validarIndice(indice);
        return libros.get(indice);
    }
    
    //eliminar libros por indice
    public void eliminar(int indice){
        validarIndice(indice);
        libros.remove(indice);
    }
    
    //filtrar libros segun su criterio por ej categoria, titulo
    public List<T> filtrar(Predicate<? super T> criterio){
        List<T> toReturn = new ArrayList<>();
        for(T libro : libros){
            if(criterio.test(libro)){
                toReturn.add(libro);
            }
        }
        return toReturn;
    }
    
    //orden natural
    public void ordenar(){
        Collections.sort(libros);
    }
    
    
    //ordenar libros con comparator
    public void ordenarCriterio(List<? extends T> lista, Comparator<T> criterio){
        lista.sort(criterio);
    }
    
    //guardar inventario en archivo binario
    public void guardarEnArchivo(Inventario<T> inventario, String path){
        try {
            File archivo = new File(path);
            File directorio = archivo.getParentFile();
            if (!directorio.exists()) {
                directorio.mkdirs(); // Crear directorios si no existen
            }
            try (FileOutputStream archivoSalida = new FileOutputStream(archivo);
                 ObjectOutputStream salida = new ObjectOutputStream(archivoSalida)) {
                salida.writeObject(inventario);
                System.out.println("Inventario serializado correctamente en: " + path);
            }
        } catch (IOException ex) {
            System.err.println("Error al serializar el inventario: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
    
    //cargar el inventario desde un archivo binario
    public List<T> cargarDesdeArchivo(String path){
        List<T> toReturn = new ArrayList<>();
        try(ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))){
            toReturn = (List<T>) input.readObject(); 

        } catch(IOException | ClassNotFoundException ex){
            System.out.println(ex.getMessage());
        
        }
        return toReturn;
    }
    
    //guardar el inventario en archivo CSV
    public void guardarEnCSV(List<? extends T> lista, String path){
        File archivo = new File(path);
        try {
            if(archivo.exists()){
                System.out.println("El archivo ya existe");
            } else {
                archivo.createNewFile();
            }
        } catch(IOException ex){
            System.out.println("Ocurrio un error al crear el archivo");
        }
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(path))){
            bw.write("dni,nombre,sueldo,sector\n");
            for (T elemento: lista){
                bw.write(elemento.toCSV() + "\n");
            }
        } catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }

    //cargar inventario desde archivo CSV
    public List<T> cargarArchivoCSV(String path){
        List<T> toReturn = new ArrayList<>();
        try(BufferedReader bf = new BufferedReader(new FileReader(path))) {
                String linea;
                bf.readLine();
                while((linea = bf.readLine()) != null){
                    if(linea.endsWith("\n")){
                        linea = linea.substring(linea.length()-1);
                    }
                    String data[] = linea.split(",");
                    if(data.length == 4){
                        int id = Integer.parseInt(data[0]);
                        String titulo = data[1];
                        String autor = data[2];
                        Categoria cat = Categoria.valueOf(data[3]);
                        Libro libro = new Libro(id, titulo, autor, cat);
                        toReturn.add((T) libro);
                    }
                }
            } catch(IOException ex){
                System.out.println(ex.getMessage());
                throw new RuntimeException("Problema al cargar empleados");
            }
        return toReturn;    
    }
}
    
    
    

