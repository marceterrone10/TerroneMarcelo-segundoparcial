package segundoparcial;

import java.io.Serializable;


public class Libro implements CSVSerializable, Serializable, Comparable<Libro>{
    private int id;
    private String titulo;
    private String autor;
    private Categoria categoria;

    public Libro(int id, String titulo, String autor, Categoria categoria) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.categoria = categoria;
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public Categoria getCategoria() {
        return categoria;
    }
    

    @Override
    public int compareTo(Libro l) {
        return Integer.compare(id, l.id);
    }

    @Override
    public String toString() {
        return "Libro{" + "id=" + id + ", titulo=" + titulo + ", autor=" + autor + ", categoria=" + categoria + '}';
    }

    @Override
    public String toCSV() {
        return id + "," + titulo + "," + autor + "," + categoria;
    }
    
    
    
}
