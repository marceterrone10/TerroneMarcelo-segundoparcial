package segundoparcial;


public interface CSVSerializable {
    
    String toCSV();
}
